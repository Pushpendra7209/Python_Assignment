x=10

x+=x+10
print(x)

x=x+10
print(x)
