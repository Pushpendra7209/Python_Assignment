x=1
y=1
z=1
print((x<y)or(not(z==y)and(z<x)))
