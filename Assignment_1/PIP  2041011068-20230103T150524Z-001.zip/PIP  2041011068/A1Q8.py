a = 300< mark < 400

grade = 'A'
print(grade.isupper())


engineer = post>4 and experience>4
