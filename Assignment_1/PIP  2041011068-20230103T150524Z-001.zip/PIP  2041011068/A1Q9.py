import math
a=1
b=20
c=4
root1=(-b+math.sqrt((b*b)-(4*a*c)))/2*a
print(root1)
        
x=3
y=4
result=(((2*x*y)-9*y)/2*x*y*y*y)-(4*y*x*x)/2*y
print(result)
       
      
