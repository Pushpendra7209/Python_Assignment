a=15&22
print(a)

b=15|22
print(b)

c=-15 & 22
print(c)

d= -15 | 22
print(d)

e = ~15
print(e)

f = ~ 22
print(f)

g=~-22
print(g)

h= ~-20
print(h)

i= 8<<3
print(i)

j=40>>3
print(j)
