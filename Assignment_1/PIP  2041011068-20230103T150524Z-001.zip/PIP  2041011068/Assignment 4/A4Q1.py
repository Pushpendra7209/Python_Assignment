x = int(input("enter a number : "))
for i in range (1,x+1):
    j=0
    #while(j<i):
    print(i,"  ",pow(2,i))
