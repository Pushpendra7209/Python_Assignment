a=(-7*20+8/16*2+54)
print(a)

b=(7**2//9%3)
print(b)

c=(7-4*2)*10-25**8/5
print(c)

d=5%10+10-25*8//5
print(d)

e='hello'*2-5
print(e)
