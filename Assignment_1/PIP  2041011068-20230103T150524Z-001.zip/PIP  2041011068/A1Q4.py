a = 5%10+10<50and 29>=29
print(a)

b= 7**2 <=5//9%3 or 'bye'  < 'Bye'
print(b)

c = 5%10 <8 and -25>1*8//5
print(c)

d= 7**2  // 4 +5>8 or 5!=6
print(d)

e=7/4 <6 and ' I am fine ' >'I am not fine'
print(e)

f = 10 + 6 *2**3!=8/4 -3 and 29 >=29/9
print(f)

g ='hello' *5 > 'hello' or 'bye' < 'Bye'
print(g)
