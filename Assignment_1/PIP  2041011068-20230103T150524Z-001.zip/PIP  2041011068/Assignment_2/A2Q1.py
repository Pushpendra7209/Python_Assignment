import math

print(math.ceil(65.65))
print(math.floor(65.47))
print(math.fabs(67.58))
print(math.fabs(3))
print(math.exp(2.7))
print(math.log(45.2))
print(math.pow(4,1/2))
print(math.sqrt(121))
print(math.radians(30))
print(math.degrees(math.pi/2))
      

