def Table(n):
    
    print(n*1)
    print(n*2)

    print(n*3)

    print(n*4)

    print(n*5)

    print(n*6)

    print(n*7)

    print(n*8)

    print(n*9)

    print(n*10)
num=int(input("enter a number and see magic : "))
Table(num)

