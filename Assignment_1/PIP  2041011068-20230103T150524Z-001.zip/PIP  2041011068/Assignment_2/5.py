a=int(input("a = "))
b= int (input("b = "))
c=a
a=b
b=c

print(" a = " ,a)
print(" b = " ,b)
