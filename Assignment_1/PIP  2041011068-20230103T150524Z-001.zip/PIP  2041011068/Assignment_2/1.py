celcius=float(input("enter a degree in celcius = "))
f=(celcius*9/5)+32
print(celcius ,"celcuis is" , f ,"farenheit")
