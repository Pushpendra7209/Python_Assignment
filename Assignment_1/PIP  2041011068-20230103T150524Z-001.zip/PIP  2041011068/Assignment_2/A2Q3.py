Python 3.8.10 (default, Jun 22 2022, 20:18:18) 
[GCC 9.4.0] on linux
Type "help", "copyright", "credits" or "license()" for more information.
>>> abs(-5.4)
5.4
>>> abs(15)
15
>>> chr(72)
'H'
>>> round(-24.9)
-25
>>> float(57)
57.0
>>> complex('1+2j')
(1+2j)
>>> divmod(5,2)
(2, 1)
>>> float(57)
57.0
>>> pow(9,2)
81
>>> max(97,88,50)
97
>>> min(55,29,99)
29
>>> max('a','b','A*B')
'b'
>>> 