#a
print("      \t\t*\t\t\n")
print("      \t*\t*\t*\t\n")
print(" *\t*\t*\t*\t*\t\n")
print("      \t*\t*\t*\t\n")
print("      \t\t*\t\t\n")

print()

#b
print("       $\t$\t$\t$\t$\n\n\n")
print("       $\t\t\t\t$\n\n\n")
print("       $\t\t\t\t$\n\n\n")
print("       $\t\t\t\t$\n\n\n")
print("       $\t$\t$\t$\t$\n\n\n")
