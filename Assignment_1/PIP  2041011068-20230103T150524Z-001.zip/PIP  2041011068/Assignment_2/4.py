import math

for x in range(1,6):
    print(x,"/t" ,x+1,math.pow(x,x+1))
