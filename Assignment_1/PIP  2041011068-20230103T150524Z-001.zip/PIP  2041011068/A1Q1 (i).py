Python 3.8.10 (default, Jun 22 2022, 20:18:18) 
[GCC 9.4.0] on linux
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
==================== RESTART: /home/student/Desktop/first.py ===================
helllo world
>>> 
==================== RESTART: /home/student/Desktop/first.py ===================
helllo world
>>> 
==================== RESTART: /home/student/Desktop/first.py ===================
helllo world
>>> 
==================== RESTART: /home/student/Desktop/first.py ===================
helllo world
>>> 2+5
7
>>> a=10
>>> a
10
>>> hello world
SyntaxError: invalid syntax
>>> print("hello world")
hello world
>>> 
============== RESTART: /home/student/Desktop/2041011068/first.py ==============
lab1
what is your namepushpendra kumar
my pushpendra kumar
>>> 
============== RESTART: /home/student/Desktop/2041011068/first.py ==============
lab1
what is your name
============== RESTART: /home/student/Desktop/2041011068/first.py ==============
lab1
what is your name
my name is  
>>> pushpendra kumar
SyntaxError: invalid syntax
>>> 
============== RESTART: /home/student/Desktop/2041011068/first.py ==============
lab1
what is your name2
my name is  2
>>> 
======================== RESTART: /home/student/A1Q1.py ========================
True
>>> 