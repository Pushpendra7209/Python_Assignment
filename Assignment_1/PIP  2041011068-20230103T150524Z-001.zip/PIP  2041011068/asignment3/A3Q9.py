aa = int(input("enter first number "))
bb = int(input("enter second number "))
def fun(a, b):
    
    c= int (a)+ int( b)
   
    return c
print("sum of two number is : ",fun(aa,bb))
