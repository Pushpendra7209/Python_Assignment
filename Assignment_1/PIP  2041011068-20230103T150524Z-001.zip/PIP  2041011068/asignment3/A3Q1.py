marks=int(input("enter a marks : "))
if(marks>=70):
    print("good")
else :
    print("average")
