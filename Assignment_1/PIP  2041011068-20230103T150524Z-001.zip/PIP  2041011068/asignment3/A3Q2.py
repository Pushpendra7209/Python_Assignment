

total = 0
count =20
while count>5:
    total+=count
count-=1   
print(total)

