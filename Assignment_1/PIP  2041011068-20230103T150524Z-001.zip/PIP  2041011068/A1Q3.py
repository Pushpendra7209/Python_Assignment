a='hi'>'hello'and 'bye'<'Bye'
print(a)

b='hi'>'hello' or 'bye'<'Bye'
print(b)

c=7>8or 5<6 and ' I am fine' >'I am not fine'
print(c)

d= 10!=9 and 29 >=29
print(d)

e= 10!=9 and 29 >=29 and 'hi' >'hello' or 'bye' <'Bye' and 7<2.5
print(e)
