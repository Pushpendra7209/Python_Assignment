Python 3.8.10 (default, Jun 22 2022, 20:18:18) 
[GCC 9.4.0] on linux
Type "help", "copyright", "credits" or "license()" for more information.
>>> a=6
>>> a==6
True
>>> a<5.9
False
>>> a>5.9
True
>>> 
>>> 
>>> 
>>> b=7
>>> b/6
1.1666666666666667
>>> b//6
1
>>> b/4
1.75
>>> b%4
3
>>> b%7
0
>>> b*2
14
>>> b**2
49
>>> 