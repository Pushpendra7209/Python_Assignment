#  i.

'''globalvar =10
def test():
     localvar = 20;
     print('Inside function test : globalvar=', globalvar)
     print('Inside function test : globalvar=', localvar)
test()
print('Inside function test : globalvar=', globalvar)
print('Inside function test : globalvar=', localvar)

output
:
 Inside function test : globalvar= 10
Inside function test : globalvar= 20
Inside function test : globalvar= 10
Traceback (most recent call last):
  File "/usr/lib/python3.8/idlelib/run.py", line 559, in runcode
    exec(code, self.locals)
  File "/home/student/Desktop/2041011068/Assignment 5/A5Q1.py", line 10, in <module>
    print('Inside function test : globalvar=', localvar)
NameError: name 'localvar' is not defined'''









#  ii.

'''globalVar = 10
def test():
    global globalVar
    localVar = 20
    globalVar = 30
    print('Inside function test : globalVar = ',globalVar)
    print('Inside fuction test : localVar= ' , localVar)

test()
print('outside function test  : globalVar=', globalVar)
'''

'''output :
Inside function test : globalVar =  30
Inside fuction test : localVar=  20
outside function test  : globalVar= 30'''








#  iii.

''' test():
     global globalVar
     localVar = 20
     globalVar = 30
     print('Inside fuction test: globalVar =' ,globalVar)
     print('inside fuction test : localVar =' , localVar)
test()
print('outside the function test: =' ,globalVar)'''

'''output:
 Inside fuction test: globalVar = 30
inside fuction test : localVar = 20
outside the function test: = 30'''





# iv.

'''def test1():
    test1.a=10
    def test2():
        test1.a=8
        print('Inside fuction test:' ,test1.a)
    test2()
    print('outsie fuction test2 :' ,test1.a)
test1()'''

'''output:
         Inside fuction test: 8
outsie fuction test2 : 8
'''
              




        

# v.

'''a=4
def f():
    a=5
    def g():
        nonlocal a
        a=10
        print('Inside fuction g, ',' a=',a)
        def h():
            nonlocal a
            a=20
            print('inside fuction h, ' ,'a=',a)
        h()
    g()
    print('Inside function f,','a=',a)
f()'''

'''output:
    Inside fuction g,   a= 10
inside fuction h,  a= 20
Inside function f, a= 20'''









# vi.


'''x=2
def test ():
    x = x+1
    print(x)
print(x)'''

'''output: 2'''







#vii.

x=2
def test ():
    global x
    x = x+1
    print(x)
print(x)


    
